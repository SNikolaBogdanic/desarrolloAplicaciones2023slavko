class UserLoginDto {
    username: string;
    password: string;
}